# LIR Check v2

Esta versión cambia el flujo: se introducen los datos del LIR y la app genera la HCC/hoja de carga calculada.

## Subir a GitHub Pages
- index.html
- styles.css
- app.js
- sw.js
- manifest.json
- icons/icon-192.png
- icons/icon-512.png
- icons/apple-touch-icon.png

## Lógica v2
- Varias líneas por cada CPT/bodega; se pueden añadir tantas como hagan falta.
- B, BF, BS y BT = equipaje; se suman sus cantidades y se multiplican por el peso medio.
- C = cargo en kg.
- M = mail en kg.
- X = sin carga; si se indica ULD, se suma su peso.
- N = sin ULD; no se suma el ULD de esa línea.
- BL y E quedan fuera de esta versión.
- CC se conserva como tipo disponible, pero NO se suma hasta definir su tratamiento.
- Pesos ULD según la tabla del Excel.
- Resultado en columnas B/C/ULD/M/O y total.

## Actualización
La versión visible es v2 y la caché es `lir-check-v2`. Al instalar la v2, el Service Worker elimina las cachés anteriores.
